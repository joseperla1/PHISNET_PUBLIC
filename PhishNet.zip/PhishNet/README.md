# PhishNet
PhishNet: Catching Scams, Not Fish

This is a fraudulent website detector that will stop you from entering sensitive information into a fraudulent-looking website.

This is a project for the PickHacks 2024 hackathon at MS&T.
