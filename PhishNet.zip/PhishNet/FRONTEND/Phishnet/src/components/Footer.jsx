
function Footer(){

    return(
        <>
        <footer>
            <hr/>
            <p>
                &copy; {new Date().getFullYear()} PhishNet 
                From the Giga brains of: James, Jason, , Jose , Shreya
            </p>
        </footer>
        </>
    )
}

export default Footer