
function Header(){

    return(
        <>
        <header>
            <h1>PhishNet</h1>
           
            <hr></hr>
        </header>
        </>
    )
}


export default Header