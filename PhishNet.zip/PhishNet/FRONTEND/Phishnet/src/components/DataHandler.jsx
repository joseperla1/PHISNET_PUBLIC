function convertToJSON(urlInput){
    return {
    suspect : urlInput,
    result : "Submitted Date",
    reason1 : "Online/Offline",
    reason2 : "Phish URL",
    reason3 : "ITS GOOGLE FOR GODS SAKE"};
}

export default convertToJSON