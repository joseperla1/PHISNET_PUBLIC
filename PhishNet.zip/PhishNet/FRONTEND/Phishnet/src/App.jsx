import './styles/App.css'

function App() {

  return (
    <>
      <h2 className="read-the-docs">
        Enter the url you suspect is phishing you
      </h2>
    </>
  )
}

export default App
